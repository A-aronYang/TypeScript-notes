<script setup lang="ts"></script>

<template>
  <div class="article-page">article</div>
</template>

<style lang="scss" scoped></style>
